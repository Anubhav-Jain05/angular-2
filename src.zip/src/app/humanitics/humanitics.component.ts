import { Component } from '@angular/core';

@Component({
  selector: 'app-humanitics',
  templateUrl: './humanitics.component.html',
  styleUrls: ['./humanitics.component.css']
})
export class HumaniticsComponent {

}
